energyApp.config(function($routeProvider,$locationProvider) {
    $routeProvider
    .when("/dayReport/:type", {
        templateUrl : "/assets/dayReport.html",
        controller : "reportController"
    })
    $locationProvider.html5Mode(true);
});