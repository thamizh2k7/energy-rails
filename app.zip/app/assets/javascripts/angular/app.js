var energyApp = angular.module('energyApp', ['ngRoute','720kb.datepicker'])
energyApp.constant('Api', {
    base: 'https://angular-coding-challenge.firebaseio.com',
    path: "/timeseries/",
    timeAdjust: 18000000
});