energyApp.controller('reportController', function ($scope,$filter,$routeParams,seriesFactory) {
    $scope.search = {}
    if($routeParams.type=="dayWise"){
        $scope.chartOptions = {
            title: {
                text: 'Energy Consumption daily Report'
            },
            series: [{
                data: []
            }]
        };
    }

    $scope.drawChart = function(){
        if(empty($scope.search.day)){
            $scope.search.day = "2016-07-01"
        }
        var startAt = moment($scope.search.day).format('YYYYMMDD'),
        endAt = moment($scope.search.day).add(1, 'd').format('YYYYMMDD')
        seriesFactory.getDayConsumption(startAt,endAt,"DEVICE-1").then(function(data){
            $scope.chartOptions.series[0].data= $filter('transformData')(data.data,startAt,endAt);
        })

    }
    $scope.drawChart();
});