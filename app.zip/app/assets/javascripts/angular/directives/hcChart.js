energyApp.directive('hcChart', function () {
    return {
        restrict: 'E',
        template: '<div></div>',
        scope: {
            options: '='
        },
        link: function (scope, element) {
            var chart = Highcharts.chart(element[0], scope.options);
            scope.$watch(function() {
                return scope.options.series;
            }, function(newVal,oldVal) {
                chart.series[0].setData(newVal[0].data);
            },true)
        }
    };
})